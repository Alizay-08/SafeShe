<?php
// Server-Sent Events endpoint for real-time notifications
// Simple implementation: authenticates user via PHP session and polls DB for new notifications

session_start();
require_once __DIR__ . '/config/db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo "Unauthorized";
    exit;
}

$userId = (int)$_SESSION['user_id'];

// set headers for SSE
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');

// Prevent script timeout
set_time_limit(0);

$lastSentId = 0; // track last notification id sent

// If client supplies last-event-id header (reconnect), use it
if (!empty($_SERVER['HTTP_LAST_EVENT_ID'])) {
    $lastSentId = (int)$_SERVER['HTTP_LAST_EVENT_ID'];
}

// Helper to send SSE event
function sse_send($event, $data, $id = null) {
    if ($id !== null) {
        echo "id: {$id}\n";
    }
    if ($event !== null) {
        echo "event: {$event}\n";
    }
    // data can be an array/object
    $payload = is_string($data) ? $data : json_encode($data);
    // split by lines per SSE spec
    $lines = explode("\n", $payload);
    foreach ($lines as $line) {
        echo "data: {$line}\n";
    }
    echo "\n";
    // flush to client
    @ob_flush();
    @flush();
}

// initial send: current unread count
$stmt = $pdo->prepare('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0');
$stmt->execute([$userId]);
$row = $stmt->fetch();
$unread = $row ? (int)$row['cnt'] : 0;
sse_send('unread_count', ['count' => $unread]);

// Long-poll loop: check every 2 seconds for new notifications
while (true) {
    // query for new notifications with id > lastSentId
    $stmt = $pdo->prepare('SELECT id, type, message, data, is_read, created_at FROM notifications WHERE user_id = ? AND id > ? ORDER BY id ASC');
    $stmt->execute([$userId, $lastSentId]);
    $new = $stmt->fetchAll();
    if ($new && count($new) > 0) {
        foreach ($new as $n) {
            $lastSentId = (int)$n['id'];
            // send full notification
            sse_send('notification', [
                'id' => $n['id'],
                'type' => $n['type'],
                'message' => $n['message'],
                'data' => json_decode($n['data'], true),
                'is_read' => (int)$n['is_read'],
                'created_at' => $n['created_at']
            ], $lastSentId);
        }
        // send updated unread count
        $stmt2 = $pdo->prepare('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0');
        $stmt2->execute([$userId]);
        $r2 = $stmt2->fetch();
        $unread = $r2 ? (int)$r2['cnt'] : 0;
        sse_send('unread_count', ['count' => $unread]);
    }

    // heartbeat to keep connection alive every 15 seconds
    sse_send(null, ['ts' => time()]);

    // sleep for 2 seconds before next check
    sleep(2);
    // Detect client disconnect
    if (connection_aborted()) {
        break;
    }
}

// close
exit;
