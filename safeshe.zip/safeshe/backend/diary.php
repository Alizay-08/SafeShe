<?php
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'add':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('INSERT INTO diary (user_id, entry) VALUES (?, ?)');
        $ok = $stmt->execute([
            $data['user_id'],
            $data['entry']
        ]);
        echo json_encode(['success' => $ok]);
        break;
    case 'list':
        $user_id = $_GET['user_id'] ?? 0;
        $stmt = $pdo->prepare('SELECT * FROM diary WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->execute([$user_id]);
        echo json_encode($stmt->fetchAll());
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
