<?php
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        $stmt = $pdo->query('SELECT * FROM helplines');
        echo json_encode($stmt->fetchAll());
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
