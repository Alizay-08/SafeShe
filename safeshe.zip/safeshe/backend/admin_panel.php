<?php
session_start();
require_once __DIR__ . '/config/db.php';
header('Content-Type: application/json');

// Ensure admin is logged in
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Forbidden: admin only']);
    exit;
}

$action = $_GET['action'] ?? '';

switch ($action) {
    // Users CRUD
    case 'list_users':
        $stmt = $pdo->query('SELECT id, name, email, trusted_contact, created_at FROM users ORDER BY created_at DESC');
        echo json_encode(['success' => true, 'users' => $stmt->fetchAll()]);
        break;
    case 'get_user':
        $id = $_GET['id'] ?? null;
        if (!$id) { echo json_encode(['success'=>false,'error'=>'Missing id']); break; }
        $stmt = $pdo->prepare('SELECT id, name, email, trusted_contact, avatar, bio FROM users WHERE id = ?');
        $stmt->execute([$id]);
        echo json_encode(['success'=>true, 'user' => $stmt->fetch()]);
        break;
    case 'update_user':
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['id'])) { echo json_encode(['success'=>false,'error'=>'Missing id']); break; }
        $stmt = $pdo->prepare('UPDATE users SET name = ?, email = ?, trusted_contact = ?, bio = ? WHERE id = ?');
        $ok = $stmt->execute([$data['name'] ?? null, $data['email'] ?? null, $data['trusted_contact'] ?? null, $data['bio'] ?? null, $data['id']]);
        echo json_encode(['success' => (bool)$ok]);
        break;
    case 'delete_user':
        $id = $_GET['id'] ?? null;
        if (!$id) { echo json_encode(['success'=>false,'error'=>'Missing id']); break; }
        $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
        $ok = $stmt->execute([$id]);
        echo json_encode(['success' => (bool)$ok]);
        break;

    // Helplines CRUD
    case 'list_helplines':
        $stmt = $pdo->query('SELECT * FROM helplines ORDER BY id DESC');
        echo json_encode(['success' => true, 'helplines' => $stmt->fetchAll()]);
        break;
    case 'create_helpline':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('INSERT INTO helplines (name, number, category) VALUES (?, ?, ?)');
        $ok = $stmt->execute([$data['name'] ?? null, $data['number'] ?? null, $data['category'] ?? null]);
        echo json_encode(['success' => (bool)$ok]);
        break;
    case 'update_helpline':
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['id'])) { echo json_encode(['success'=>false,'error'=>'Missing id']); break; }
        $stmt = $pdo->prepare('UPDATE helplines SET name = ?, number = ?, category = ? WHERE id = ?');
        $ok = $stmt->execute([$data['name'] ?? null, $data['number'] ?? null, $data['category'] ?? null, $data['id']]);
        echo json_encode(['success' => (bool)$ok]);
        break;
    case 'delete_helpline':
        $id = $_GET['id'] ?? null;
        if (!$id) { echo json_encode(['success'=>false,'error'=>'Missing id']); break; }
        $stmt = $pdo->prepare('DELETE FROM helplines WHERE id = ?');
        $ok = $stmt->execute([$id]);
        echo json_encode(['success' => (bool)$ok]);
        break;

    // Stories
    case 'pending_stories':
        $stmt = $pdo->query('SELECT s.*, u.name FROM stories s JOIN users u ON s.user_id = u.id WHERE s.approved = 0 ORDER BY s.created_at DESC');
        echo json_encode(['success' => true, 'stories' => $stmt->fetchAll()]);
        break;
    case 'approve_story':
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['id'])) { echo json_encode(['success'=>false,'error'=>'Missing id']); break; }
        $stmt = $pdo->prepare('UPDATE stories SET approved = 1 WHERE id = ?');
        $ok = $stmt->execute([$data['id']]);
        // create notification
        if ($ok) {
            $stmt2 = $pdo->prepare('SELECT user_id FROM stories WHERE id = ?');
            $stmt2->execute([$data['id']]);
            $row = $stmt2->fetch();
            if ($row) {
                $stmt3 = $pdo->prepare('INSERT INTO notifications (user_id, type, message, data, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())');
                $stmt3->execute([$row['user_id'], 'story', 'Your success story has been approved by admin.', json_encode(['story_id' => $data['id']])]);
            }
        }
        echo json_encode(['success' => (bool)$ok]);
        break;
    case 'delete_story':
        $id = $_GET['id'] ?? null;
        if (!$id) { echo json_encode(['success'=>false,'error'=>'Missing id']); break; }
        $stmt = $pdo->prepare('DELETE FROM stories WHERE id = ?');
        $ok = $stmt->execute([$id]);
        echo json_encode(['success' => (bool)$ok]);
        break;

    // Admin profile
    case 'get_admin_profile':
        $stmt = $pdo->prepare('SELECT id, email, created_at FROM admin WHERE id = ?');
        $stmt->execute([$_SESSION['admin_id']]);
        echo json_encode(['success' => true, 'admin' => $stmt->fetch()]);
        break;
    case 'update_admin_profile':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('UPDATE admin SET email = ?, password = ? WHERE id = ?');
        $ok = $stmt->execute([$data['email'] ?? null, $data['password'] ?? null, $_SESSION['admin_id']]);
        echo json_encode(['success' => (bool)$ok]);
        break;
    case 'delete_admin':
        // careful: deletes current admin
        $stmt = $pdo->prepare('DELETE FROM admin WHERE id = ?');
        $ok = $stmt->execute([$_SESSION['admin_id']]);
        if ($ok) session_destroy();
        echo json_encode(['success' => (bool)$ok]);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
}
