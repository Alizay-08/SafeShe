-- Trigger: when a story is approved (approved changes from 0 to 1), insert a notification for the story's author
DELIMITER $$
DROP TRIGGER IF EXISTS trg_stories_after_update$$
CREATE TRIGGER trg_stories_after_update
AFTER UPDATE ON stories
FOR EACH ROW
BEGIN
  IF OLD.approved = 0 AND NEW.approved = 1 THEN
    INSERT INTO notifications (user_id, type, message, data, is_read, created_at)
    VALUES (NEW.user_id, 'story', CONCAT('Your success story has been approved by admin.'), JSON_OBJECT('story_id', NEW.id), 0, NOW());
  END IF;
END$$
DELIMITER ;
