<?php
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'submit':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('INSERT INTO reports (user_id, type, description, location) VALUES (?, ?, ?, ?)');
        $ok = $stmt->execute([
            $data['user_id'],
            $data['type'],
            $data['description'],
            $data['location']
        ]);
        echo json_encode(['success' => $ok]);
        break;
    case 'list':
        $stmt = $pdo->query('SELECT * FROM reports ORDER BY created_at DESC');
        echo json_encode($stmt->fetchAll());
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
