<?php
// Admin login/logout/session API
session_start();
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
    $data = json_decode(file_get_contents('php://input'), true);
    $email = trim($data['email']);
    $password = trim($data['password']);
    $stmt = $pdo->prepare('SELECT * FROM admin WHERE email = ?');
    $stmt->execute([$email]);
    $admin = $stmt->fetch();
            // Plain text password check (no hash)
            if ($admin && $password === $admin['password']) {
        $_SESSION['admin_id'] = $admin['id'];
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
    }
    break;
    case 'logout':
        session_destroy();
        echo json_encode(['success' => true]);
        break;
    case 'check':
        echo json_encode(['logged_in' => isset($_SESSION['admin_id'])]);
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
