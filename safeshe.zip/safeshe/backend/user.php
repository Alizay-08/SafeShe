<?php
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'register':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password, trusted_contact) VALUES (?, ?, ?, ?)');
        $ok = $stmt->execute([
            $data['name'],
            $data['email'],
            password_hash($data['password'], PASSWORD_DEFAULT),
            $data['trusted_contact'] ?? null
        ]);
        echo json_encode(['success' => $ok]);
        break;
    case 'login':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$data['email']]);
        $user = $stmt->fetch();
        if ($user && password_verify($data['password'], $user['password'])) {
            unset($user['password']);
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
        }
        break;
    case 'list':
    $stmt = $pdo->query("SELECT id, name, email, trusted_contact, created_at FROM users ORDER BY id ASC");
        $users = $stmt->fetchAll();
        echo json_encode($users);
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
