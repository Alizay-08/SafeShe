<?php
session_start();
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

// simple auth helper
function require_auth() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }
    return $_SESSION['user_id'];
}

switch ($action) {
    case 'get':
        $user_id = require_auth();
        $stmt = $pdo->prepare('SELECT id, name, email, trusted_contact, avatar, bio, created_at FROM users WHERE id = ?');
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        echo json_encode(['success' => true, 'user' => $user]);
        break;

    case 'update':
        $user_id = require_auth();
        // accept multipart/form-data for avatar or JSON
        if (strpos($_SERVER['CONTENT_TYPE'] ?? '', 'multipart/form-data') !== false) {
            $name = $_POST['name'] ?? null;
            $trusted = $_POST['trusted_contact'] ?? null;
            $bio = $_POST['bio'] ?? null;
            // handle avatar upload
            if (!empty($_FILES['avatar']['tmp_name'])) {
                $uploadDir = __DIR__ . '/../assets/uploads/avatars';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                // validate file size (max 2MB) and type
                $maxBytes = 2 * 1024 * 1024;
                if ($_FILES['avatar']['size'] > $maxBytes) {
                    echo json_encode(['success' => false, 'error' => 'Avatar too large (max 2MB)']);
                    exit;
                }
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $_FILES['avatar']['tmp_name']);
                finfo_close($finfo);
                $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/svg+xml' => 'svg'];
                if (!isset($allowed[$mime])) {
                    echo json_encode(['success' => false, 'error' => 'Invalid avatar type']);
                    exit;
                }
                $ext = $allowed[$mime];
                $filename = $user_id . '_' . time() . '.' . $ext;
                $dest = $uploadDir . '/' . $filename;
                if (move_uploaded_file($_FILES['avatar']['tmp_name'], $dest)) {
                    $avatarPath = 'assets/uploads/avatars/' . $filename;
                    $stmt = $pdo->prepare('UPDATE users SET avatar = ? WHERE id = ?');
                    $stmt->execute([$avatarPath, $user_id]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file']);
                    exit;
                }
            }
            $fields = [];
            $params = [];
            if ($name !== null) { $fields[] = 'name = ?'; $params[] = $name; }
            if ($trusted !== null) { $fields[] = 'trusted_contact = ?'; $params[] = $trusted; }
            if ($bio !== null) { $fields[] = 'bio = ?'; $params[] = $bio; }
            if (count($fields)) {
                $params[] = $user_id;
                $sql = 'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?';
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
            }
            echo json_encode(['success' => true]);
            break;
        }

        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $fields = [];
        $params = [];
        if (isset($data['name'])) { $fields[] = 'name = ?'; $params[] = $data['name']; }
        if (isset($data['trusted_contact'])) { $fields[] = 'trusted_contact = ?'; $params[] = $data['trusted_contact']; }
        if (isset($data['bio'])) { $fields[] = 'bio = ?'; $params[] = $data['bio']; }
        if (count($fields)) {
            $params[] = $user_id = require_auth();
            $sql = 'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?';
            $stmt = $pdo->prepare($sql);
            $ok = $stmt->execute($params);
            echo json_encode(['success' => (bool)$ok]);
        } else {
            echo json_encode(['success' => false, 'error' => 'No fields']);
        }
        break;

    case 'delete':
        $user_id = require_auth();
        $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
        $ok = $stmt->execute([$user_id]);
        echo json_encode(['success' => (bool)$ok]);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
}
