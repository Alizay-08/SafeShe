<?php
session_start();
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

function require_auth() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }
    return $_SESSION['user_id'];
}

switch ($action) {
    case 'list':
        $user_id = require_auth();
        $stmt = $pdo->prepare('SELECT id, type, message, data, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->execute([$user_id]);
        $rows = $stmt->fetchAll();
        // decode JSON data column for each notification
        foreach ($rows as &$r) {
            if (isset($r['data']) && $r['data'] !== null) {
                $decoded = json_decode($r['data'], true);
                $r['data'] = $decoded === null ? $r['data'] : $decoded;
            }
        }
        echo json_encode(['success' => true, 'notifications' => $rows]);
        break;

    case 'unread_count':
        $user_id = require_auth();
        $stmt = $pdo->prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0');
        $stmt->execute([$user_id]);
        $c = $stmt->fetchColumn();
        echo json_encode(['success' => true, 'count' => (int)$c]);
        break;

    case 'mark_read':
        $user_id = require_auth();
        $id = $_GET['id'] ?? null;
        if ($id) {
            $stmt = $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?');
            $stmt->execute([$id, $user_id]);
            echo json_encode(['success' => true]);
        } else {
            // mark all
            $stmt = $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?');
            $stmt->execute([$user_id]);
            echo json_encode(['success' => true]);
        }
        break;

    case 'create':
        // create notification (admin/backoffice will call this)
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($data['user_id']) || empty($data['message'])) {
            echo json_encode(['success' => false, 'error' => 'Missing fields']);
            exit;
        }
        $stmt = $pdo->prepare('INSERT INTO notifications (user_id, type, message, data, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())');
        $stmt->execute([$data['user_id'], $data['type'] ?? 'info', $data['message'], $data['data'] ?? null]);
        echo json_encode(['success' => true]);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
}
