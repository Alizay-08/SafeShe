<?php
// backend/chatbot.php
header('Content-Type: application/json');

// Expanded Q&A pairs for broader coverage
$faq = [
    [
        'questions' => ['hello', 'hi', 'hey', 'good morning', 'good evening'],
        'answer' => 'Hello! How can I help you today?'
    ],
    [
        'questions' => ['help', 'support', 'assist', 'how to use', 'guide'],
        'answer' => 'Sure! You can ask about features, safety tips, or how to use Safeshe.'
    ],
    [
        'questions' => ['sos', 'emergency', 'panic', 'alert'],
        'answer' => 'To use the SOS feature, click the SOS button on your dashboard for instant help.'
    ],
    [
        'questions' => ['helpline', 'contact', 'emergency number', 'phone number'],
        'answer' => 'You can find helpline numbers in the Helplines section of your dashboard.'
    ],
    [
        'questions' => ['mood', 'mood tracker', 'emotion', 'feeling'],
        'answer' => 'The Mood Tracker lets you log your feelings and track your emotional health.'
    ],
    [
        'questions' => ['diary', 'journal', 'write thoughts', 'notes'],
        'answer' => 'Use the Diary to write your thoughts and experiences securely.'
    ],
    [
        'questions' => ['story', 'share story', 'inspire', 'experience'],
        'answer' => 'Share your story anonymously in the Stories section to inspire others.'
    ],
    [
        'questions' => ['cyber', 'cyber safety', 'online safety', 'privacy', 'internet'],
        'answer' => 'Always keep your information private and report suspicious activity.'
    ],
    [
        'questions' => ['fake call', 'call', 'escape', 'uncomfortable'],
        'answer' => 'The Fake Call feature helps you get out of uncomfortable situations discreetly.'
    ],
    [
        'questions' => ['language', 'change language', 'translate'],
        'answer' => 'You can change the language using the toggle at the top right of your dashboard.'
    ],
    [
        'questions' => ['bye', 'goodbye', 'see you'],
        'answer' => 'Goodbye! Stay safe and reach out if you need anything.'
    ],
    [
        'questions' => ['features', 'what can you do', 'what features'],
        'answer' => 'Safeshe offers SOS, helplines, mood tracker, diary, stories, fake call, and more!'
    ],
    [
        'questions' => ['admin', 'admin panel', 'manage users'],
        'answer' => 'The admin panel is for authorized admins to manage users, stories, and reports.'
    ],
    [
        'questions' => ['privacy', 'data', 'secure', 'security'],
        'answer' => 'Your privacy is our priority. All your data is securely stored and never shared.'
    ],
    [
        'questions' => ['pwa', 'install app', 'mobile app'],
        'answer' => 'Safeshe is a PWA! You can install it on your device for quick access.'
    ],
    [
        'questions' => ['responsive', 'mobile', 'tablet', 'desktop'],
        'answer' => 'Safeshe is fully responsive and works on all devices.'
    ],
];

$input = strtolower(trim($_POST['message'] ?? ''));
$response = '';

// Smarter partial/fuzzy matching
function smart_match($input, $questions) {
    foreach ($questions as $q) {
        if (strpos($input, $q) !== false) return true;
        // Fuzzy: allow 1 char difference (Levenshtein)
        if (levenshtein($input, $q) <= 2) return true;
    }
    return false;
}

foreach ($faq as $item) {
    if (smart_match($input, $item['questions'])) {
        $response = $item['answer'];
        break;
    }
}

if (!$response) {
    // Try to suggest something
    $suggest = [];
    foreach ($faq as $item) {
        foreach ($item['questions'] as $q) {
            if (similar_text($input, $q, $percent) && $percent > 50) {
                $suggest[] = $q;
            }
        }
    }
    if ($suggest) {
        $response = 'Did you mean: ' . implode(', ', array_unique($suggest)) . '?';
    } else {
        $response = 'Sorry, I did not understand that. You can ask about SOS, helplines, mood tracker, diary, stories, fake call, or any Safeshe feature!';
    }
}
echo json_encode(['reply' => $response]);
