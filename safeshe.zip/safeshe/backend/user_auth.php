<?php
// backend/user_auth.php
session_start();
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$data['email']]);
        $user = $stmt->fetch();
        if ($user && password_verify($data['password'], $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            unset($user['password']);
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
        }
        break;
    case 'logout':
        session_destroy();
        echo json_encode(['success' => true]);
        break;
    case 'check':
        echo json_encode(['logged_in' => isset($_SESSION['user_id']) ? true : false, 'user_id' => $_SESSION['user_id'] ?? null]);
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
