<?php
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'stats':
        $users = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
        $reports = $pdo->query('SELECT COUNT(*) FROM reports')->fetchColumn();
        $stories = $pdo->query('SELECT COUNT(*) FROM stories WHERE approved = 0')->fetchColumn();
        $moods = $pdo->query('SELECT COUNT(*) FROM moods')->fetchColumn();
        echo json_encode([
            'users' => $users,
            'reports' => $reports,
            'stories' => $stories,
            'moods' => $moods
        ]);
        break;
    case 'pending_stories':
        $stmt = $pdo->query('SELECT s.*, u.name FROM stories s JOIN users u ON s.user_id = u.id WHERE s.approved = 0 ORDER BY s.created_at DESC');
        echo json_encode($stmt->fetchAll());
        break;
    case 'approve_story':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('UPDATE stories SET approved = 1 WHERE id = ?');
        $ok = $stmt->execute([$data['id']]);
        echo json_encode(['success' => $ok]);
        break;
    case 'user_list':
    case 'list_users':
    case 'users':
    case 'list':
        $stmt = $pdo->query('SELECT id, name, email, trusted_contact, created_at FROM users ORDER BY created_at DESC');
        echo json_encode($stmt->fetchAll());
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
