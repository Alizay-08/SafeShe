<?php
session_start();
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

function require_auth() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }
    return $_SESSION['user_id'];
}

switch ($action) {
    case 'submit':
        // user must be logged in; ignore any user_id from the client
        $user_id = require_auth();
        $data = json_decode(file_get_contents('php://input'), true);
        $storyText = $data['story'] ?? '';
        $stmt = $pdo->prepare('INSERT INTO stories (user_id, story) VALUES (?, ?)');
        $ok = $stmt->execute([
            $user_id,
            $storyText
        ]);
        echo json_encode(['success' => (bool)$ok]);
        break;
    case 'list':
        $stmt = $pdo->query('SELECT s.*, u.name FROM stories s JOIN users u ON s.user_id = u.id WHERE s.approved = 1 ORDER BY s.created_at DESC');
        echo json_encode($stmt->fetchAll());
        break;
    case 'approve':
        // require admin privileges
        if (!isset($_SESSION['admin_id'])) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Forbidden: admin only']);
            break;
        }
        $data = json_decode(file_get_contents('php://input'), true);
        $storyId = $data['id'] ?? null;
        if (!$storyId) {
            echo json_encode(['success' => false, 'error' => 'Missing story id']);
            break;
        }
        // mark story approved
        $stmt = $pdo->prepare('UPDATE stories SET approved = 1 WHERE id = ?');
        $ok = $stmt->execute([$storyId]);
        // fetch story author
        $stmt2 = $pdo->prepare('SELECT user_id FROM stories WHERE id = ?');
        $stmt2->execute([$storyId]);
        $row = $stmt2->fetch();
        $notifCreated = false;
        $notifId = null;
        if ($row) {
            $user_id = $row['user_id'];
            $message = 'Your success story has been approved by admin.';
            try {
                $stmt3 = $pdo->prepare('INSERT INTO notifications (user_id, type, message, data, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())');
                $stmt3->execute([$user_id, 'story', $message, json_encode(['story_id' => $storyId])]);
                $notifCreated = true;
                $notifId = $pdo->lastInsertId();
                // log
                @mkdir(__DIR__ . '/logs', 0755, true);
                @file_put_contents(__DIR__ . '/logs/notifications.log', date('c') . " - Created notification {$notifId} for user {$user_id} (story {$storyId})\n", FILE_APPEND);
            } catch (Exception $e) {
                // keep going but report error and log it
                $notifCreated = false;
                @mkdir(__DIR__ . '/logs', 0755, true);
                @file_put_contents(__DIR__ . '/logs/notifications.log', date('c') . " - Failed to create notification for user {$user_id} (story {$storyId}): " . $e->getMessage() . "\n", FILE_APPEND);
            }
        }
        echo json_encode(['success' => (bool)$ok, 'notification_created' => $notifCreated, 'notification_id' => $notifId]);
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
