<?php
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'log':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare('INSERT INTO moods (user_id, mood, mood_date) VALUES (?, ?, ?)');
        $ok = $stmt->execute([
            $data['user_id'],
            $data['mood'],
            $data['mood_date']
        ]);
        echo json_encode(['success' => $ok]);
        break;
    case 'week':
        $user_id = $_GET['user_id'] ?? 0;
        $stmt = $pdo->prepare('SELECT mood, mood_date FROM moods WHERE user_id = ? AND mood_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) ORDER BY mood_date');
        $stmt->execute([$user_id]);
        echo json_encode($stmt->fetchAll());
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}
