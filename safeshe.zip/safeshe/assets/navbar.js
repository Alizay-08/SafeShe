document.addEventListener('DOMContentLoaded', () => {
  const avatar = document.getElementById('navAvatar');
  if (!avatar) return;
  async function load() {
    try {
      const res = await fetch('../backend/profile.php?action=get', { credentials: 'same-origin' });
      const data = await res.json();
      if (data.success && data.user) {
        if (data.user.avatar) avatar.src = '../' + data.user.avatar.replace(/^\/+/, '');
        else avatar.src = '../assets/default-avatar.svg';
      }
    } catch (e) {
      console.error('Failed to load nav avatar', e);
    }
  }
  load();
});
