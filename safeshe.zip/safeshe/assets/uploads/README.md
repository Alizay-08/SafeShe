This folder stores uploaded user avatars.

Ensure the webserver/PHP process has write permission to this folder.
