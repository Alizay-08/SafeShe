// admin.js - simple admin panel interactions
async function api(action, method='GET', body=null) {
  const url = `../backend/admin_panel.php?action=${action}`;
  const opts = { method, credentials: 'same-origin', headers: {} };
  if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  const res = await fetch(url, opts);
  return res.json();
}

function showSection(id) {
  document.querySelectorAll('.admin-section').forEach(s => s.style.display = 'none');
  document.getElementById(id).style.display = 'block';
}

document.addEventListener('DOMContentLoaded', () => {
  // nav
  document.querySelectorAll('.list-group a').forEach(a => {
    a.addEventListener('click', (e) => { e.preventDefault(); document.querySelectorAll('.list-group a').forEach(x=>x.classList.remove('active')); a.classList.add('active'); showSection(a.getAttribute('href').substring(1)); });
  });
  // load users
  loadUsers();
  // load helplines
  loadHelplines();
  // load pending stories
  loadStories();
  // admin profile
  loadAdminProfile();
  // create helpline modal
  document.getElementById('createHelplineBtn').addEventListener('click', () => {
    const modal = new bootstrap.Modal(document.getElementById('helplineModal'));
    const form = document.getElementById('helplineForm'); form.reset(); form.id.value = '';
    modal.show();
  });

  // create user modal
  document.getElementById('createUserBtn').addEventListener('click', () => {
    const modal = new bootstrap.Modal(document.getElementById('userModal'));
    const form = document.getElementById('userForm'); form.reset(); form.id.value = '';
    modal.show();
  });

  // confirm modal ok handler
  document.getElementById('confirmOk').addEventListener('click', () => {
    const cb = document.getElementById('confirmOk').dataset.callback;
    if (cb && window[cb]) window[cb]();
    const m = bootstrap.Modal.getInstance(document.getElementById('confirmModal'));
    if (m) m.hide();
  });
});

async function loadUsers() {
  const res = await api('list_users');
  const tbody = document.querySelector('#usersTable tbody'); tbody.innerHTML = '';
  res.users.forEach(u => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${u.id}</td><td>${u.name||''}</td><td>${u.email||''}</td><td>${u.trusted_contact||''}</td><td>
      <button class="btn btn-sm btn-primary me-1" onclick="editUser(${u.id})">Edit</button>
      <button class="btn btn-sm btn-danger" onclick="deleteUser(${u.id})">Delete</button>
    </td>`;
    tbody.appendChild(tr);
  });
}

async function editUser(id) {
  const resp = await fetch(`../backend/admin_panel.php?action=get_user&id=${id}`, {credentials:'same-origin'});
  const data = await resp.json();
  const u = data.user;
  const modalEl = document.getElementById('userModal');
  const modal = new bootstrap.Modal(modalEl);
  const form = document.getElementById('userForm');
  form.id.value = u.id; form.name.value = u.name || ''; form.email.value = u.email || ''; form.trusted_contact.value = u.trusted_contact || ''; form.bio.value = u.bio || '';
  modal.show();
}

async function deleteUser(id) {
  const modal = new bootstrap.Modal(document.getElementById('confirmModal'));
  document.getElementById('confirmBody').textContent = 'Delete user?';
  document.getElementById('confirmOk').dataset.callback = `__deleteUser_${id}`;
  window[`__deleteUser_${id}`] = async () => { const resp = await fetch(`../backend/admin_panel.php?action=delete_user&id=${id}`, {method:'POST', credentials:'same-origin'}); const r = await resp.json(); if (r.success) loadUsers(); else alert('Failed'); delete window[`__deleteUser_${id}`]; };
  modal.show();
}

async function loadHelplines() {
  const res = await api('list_helplines');
  const tbody = document.querySelector('#helplinesTable tbody'); tbody.innerHTML = '';
  res.helplines.forEach(h => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${h.id}</td><td>${h.name}</td><td>${h.number}</td><td>${h.category||''}</td><td>
      <button class="btn btn-sm btn-primary me-1" onclick="editHelpline(${h.id})">Edit</button>
      <button class="btn btn-sm btn-danger" onclick="deleteHelpline(${h.id})">Delete</button>
    </td>`;
    tbody.appendChild(tr);
  });
}

async function editHelpline(id) {
  const resp = await fetch(`../backend/admin_panel.php?action=list_helplines`, {credentials:'same-origin'});
  const r = await resp.json();
  const h = r.helplines.find(x=>x.id==id);
  const modalEl = document.getElementById('helplineModal');
  const modal = new bootstrap.Modal(modalEl);
  const form = document.getElementById('helplineForm');
  form.id.value = h.id; form.name.value = h.name; form.number.value = h.number; form.category.value = h.category || '';
  modal.show();
}

async function deleteHelpline(id) {
  const modal = new bootstrap.Modal(document.getElementById('confirmModal'));
  document.getElementById('confirmBody').textContent = 'Delete helpline?';
  document.getElementById('confirmOk').dataset.callback = `__deleteHelpline_${id}`;
  window[`__deleteHelpline_${id}`] = async () => { const resp = await fetch(`../backend/admin_panel.php?action=delete_helpline&id=${id}`, {method:'POST', credentials:'same-origin'}); const r = await resp.json(); if (r.success) loadHelplines(); else alert('Failed'); delete window[`__deleteHelpline_${id}`]; };
  modal.show();
}

async function loadStories() {
  const res = await api('pending_stories');
  const tbody = document.querySelector('#storiesTable tbody'); tbody.innerHTML = '';
  res.stories.forEach(s => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${s.id}</td><td>${s.name}</td><td>${s.story}</td><td>
      <button class="btn btn-sm btn-success me-1" onclick="approveStory(${s.id})">Approve</button>
      <button class="btn btn-sm btn-danger" onclick="deleteStory(${s.id})">Delete</button>
    </td>`;
    tbody.appendChild(tr);
  });
}

async function approveStory(id) {
  const modal = new bootstrap.Modal(document.getElementById('confirmModal'));
  document.getElementById('confirmBody').textContent = 'Approve this story?';
  document.getElementById('confirmOk').dataset.callback = `__approve_${id}`;
  window[`__approve_${id}`] = async () => { const res = await api('approve_story','POST',{id}); if (res.success) loadStories(); else alert('Failed'); delete window[`__approve_${id}`]; };
  modal.show();
}

async function deleteStory(id) { if (!confirm('Delete story?')) return; const r = await fetch(`../backend/admin_panel.php?action=delete_story&id=${id}`, {method:'POST', credentials:'same-origin'}); const d = await r.json(); if (d.success) loadStories(); else alert('Failed'); }

// modal submit handlers
document.addEventListener('submit', async (e) => {
  if (e.target.id === 'userForm') {
    e.preventDefault(); const form = e.target; const body = { id: form.id.value || null, name: form.name.value, email: form.email.value, trusted_contact: form.trusted_contact.value, bio: form.bio.value }; const res = await api('update_user','POST', body); if (res.success) { loadUsers(); bootstrap.Modal.getInstance(form.closest('.modal')).hide(); } else alert('Failed');
  }
  if (e.target.id === 'helplineForm') {
    e.preventDefault(); const form = e.target; const id = form.id.value; const body = { name: form.name.value, number: form.number.value, category: form.category.value };
    if (id) { body.id = id; const res = await api('update_helpline','POST', body); if (res.success) { loadHelplines(); bootstrap.Modal.getInstance(form.closest('.modal')).hide(); } else alert('Failed'); }
    else { const res = await api('create_helpline','POST', body); if (res.success) { loadHelplines(); bootstrap.Modal.getInstance(form.closest('.modal')).hide(); } else alert('Failed'); }
  }
});

async function loadAdminProfile() {
  const res = await api('get_admin_profile');
  if (res.success && res.admin) {
    const form = document.getElementById('adminProfileForm'); form.email.value = res.admin.email || '';
  }
  document.getElementById('adminProfileForm').addEventListener('submit', async (e) => { e.preventDefault(); const email = e.target.email.value; const password = e.target.password.value; const r = await api('update_admin_profile','POST',{email,password}); alert(r.success ? 'Saved' : 'Failed'); });
}
// Safeshe Admin Panel JS
// Fetch and render analytics, stories, reports, and users

document.addEventListener('DOMContentLoaded', () => {
  // Stats
  fetch('../backend/admin.php?action=stats')
    .then(res => res.json())
    .then(stats => {
      document.getElementById('statUsers').textContent = stats.users || 0;
      document.getElementById('statReports').textContent = stats.reports || 0;
      document.getElementById('statStories').textContent = stats.stories || 0;
      document.getElementById('statMoods').textContent = stats.moods || 0;
    });

  // Pending Stories
  fetch('../backend/admin.php?action=pending_stories')
    .then(res => res.json())
    .then(stories => {
      const tbody = document.getElementById('pendingStories');
      tbody.innerHTML = '';
      stories.forEach(story => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${story.name}</td><td>${story.story}</td><td><button class='btn btn-success btn-sm' onclick='approveStory(${story.id}, this)'>Approve</button></td>`;
        tbody.appendChild(tr);
      });
    });

  // Recent Reports
  fetch('../backend/report.php?action=list')
    .then(res => res.json())
    .then(reports => {
      const tbody = document.getElementById('recentReports');
      tbody.innerHTML = '';
      reports.slice(0, 10).forEach(r => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${r.user_id}</td><td>${r.type}</td><td>${r.location}</td><td>${r.created_at.slice(0,10)}</td>`;
        tbody.appendChild(tr);
      });
    });

  // User Management
  fetch('../backend/user.php?action=list')
    .then(res => res.json())
    .then(users => {
      const tbody = document.getElementById('userTable');
      tbody.innerHTML = '';
      users.forEach(u => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${u.id}</td><td>${u.name}</td><td>${u.email}</td><td>${u.trusted_contact || ''}</td><td>${u.created_at ? u.created_at.slice(0,10) : ''}</td>`;
        tbody.appendChild(tr);
      });
    });
});

function approveStory(id, btn) {
  fetch('../backend/admin.php?action=approve_story', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id })
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        btn.closest('tr').remove();
        Swal.fire('Story approved!');
      }
    });
}
