// Simple fetch-based notifications client (non-real-time)
function updateBadge(count) {
  const badge = document.getElementById('notifCount');
  if (!badge) return;
  badge.textContent = count > 0 ? count : '';
}

async function fetchUnreadCount() {
  try {
    const res = await fetch('../backend/notifications.php?action=unread_count', { credentials: 'same-origin' });
    const data = await res.json();
    if (data.success) updateBadge(data.count);
  } catch (e) { console.error(e); }
}

async function fetchNotificationsAndRender() {
  try {
    const res = await fetch('../backend/notifications.php?action=list', { credentials: 'same-origin' });
    const data = await res.json();
    if (data.success) {
      const container = document.getElementById('notifList');
      if (!container) return;
      container.innerHTML = '';
      data.notifications.forEach(n => {
        const li = document.createElement('li');
        li.className = 'dropdown-item';
        li.innerHTML = `<div><strong>${n.type}</strong> - ${n.message}<br><small class="text-muted">${n.created_at}</small></div>`;
        container.appendChild(li);
      });
    }
  } catch (e) { console.error(e); }
}

document.addEventListener('DOMContentLoaded', () => {
  const bell = document.getElementById('notifBell');
  if (!bell) return;
  // fetch unread count once on load
  fetchUnreadCount();

  bell.addEventListener('click', async () => {
    await fetchNotificationsAndRender();
    // mark all read
    fetch('../backend/notifications.php?action=mark_read', { method: 'POST', credentials: 'same-origin' })
      .then(() => updateBadge(0))
      .catch(() => {});
  });
});
