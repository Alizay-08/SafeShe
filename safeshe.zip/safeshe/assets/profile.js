document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('profileForm');
  const nameEl = document.getElementById('name');
  const trustedEl = document.getElementById('trusted_contact');
  const bioEl = document.getElementById('bio');
  const avatarImg = document.getElementById('avatarImg');
  const avatarInput = document.getElementById('avatar');
  const MAX_BYTES = 2 * 1024 * 1024; // 2MB
  const ALLOWED = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];

  async function loadProfile() {
    const res = await fetch('../backend/profile.php?action=get', { credentials: 'same-origin' });
    const data = await res.json();
    if (data.success && data.user) {
      nameEl.value = data.user.name || '';
      trustedEl.value = data.user.trusted_contact || '';
      bioEl.value = data.user.bio || '';
      document.getElementById('nameHeading').textContent = data.user.name || 'Name';
      document.getElementById('emailText').textContent = data.user.email || '';
      if (data.user.avatar) {
        avatarImg.src = '../' + data.user.avatar.replace(/^\/+/, '');
      } else {
        avatarImg.src = '../assets/default-avatar.svg';
      }
    }
  }

  // preview and validate avatar client-side
  avatarInput && avatarInput.addEventListener('change', (e) => {
    const f = e.target.files[0];
    if (!f) return;
    if (!ALLOWED.includes(f.type)) {
      alert('Allowed image types: JPG, PNG, WEBP, SVG');
      avatarInput.value = '';
      return;
    }
    if (f.size > MAX_BYTES) {
      alert('Max avatar size is 2MB');
      avatarInput.value = '';
      return;
    }
    const url = URL.createObjectURL(f);
    avatarImg.src = url;
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = new FormData(form);
    const res = await fetch('../backend/profile.php?action=update', { method: 'POST', body: f, credentials: 'same-origin' });
    const data = await res.json();
    if (data.success) {
      alert('Profile updated');
      loadProfile();
    } else {
      alert('Error updating profile');
    }
  });

  loadProfile();
});
