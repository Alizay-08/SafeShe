
// Dashboard logic for Safeshe (session-based)
document.body.style.display = 'none';
fetch('../backend/user_auth.php?action=check')
  .then(res => res.json())
  .then(data => {
    if (!data.logged_in) {
      localStorage.removeItem('user');
      window.location.replace('login.html');
    } else {
      document.body.style.display = '';
    }
  });

const user = JSON.parse(localStorage.getItem('user'));

// Language toggle persistence
const lang = localStorage.getItem('lang') || 'en';
if (document.getElementById('langToggle')) {
  document.getElementById('langToggle').value = lang;
}

document.getElementById('logoutBtn').onclick = () => {
  localStorage.removeItem('user');
  document.body.style.display = 'none';
  fetch('../backend/user_auth.php?action=logout')
    .then(() => {
      window.location.replace('login.html');
    });
};

// Helplines
fetch('../backend/helplines.php?action=list')
  .then(res => res.json())
  .then(data => {
    const list = document.getElementById('helplineList');
    list.innerHTML = '';
    data.forEach(h => {
      const li = document.createElement('li');
      li.className = 'list-group-item';
      li.innerHTML = `<b>${h.name}</b>: <a href="tel:${h.number}">${h.number}</a>`;
      list.appendChild(li);
    });
  });

// Mood Tracker
const moodForm = document.getElementById('moodForm');
const moodSelect = document.getElementById('moodSelect');
const moodChartCtx = document.getElementById('moodChart').getContext('2d');
let moodChart;


// Mood color mapping
const moodColors = {
  'Happy': '#ffd600',
  'Sad': '#2196f3',
  'Angry': '#e53935',
  'Anxious': '#8e24aa',
  'Confident': '#43a047',
  // fallback
  'default': '#e83e8c'
};

function loadMoodChart() {
  fetch(`../backend/mood.php?action=week&user_id=${user.id}`)
    .then(res => res.json())
    .then(data => {
      const labels = data.map(m => m.mood_date);
      const moods = data.map(m => m.mood);
      const bgColors = moods.map(m => moodColors[m] || moodColors['default']);
      if (moodChart) moodChart.destroy();
      moodChart = new Chart(moodChartCtx, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: 'Mood',
            data: moods.map(m => 1),
            backgroundColor: bgColors,
            borderRadius: 18,
            maxBarThickness: 36,
            borderSkipped: false,
            borderWidth: 0,
            hoverBackgroundColor: bgColors,
            barPercentage: 0.7,
            categoryPercentage: 0.7,
          }]
        },
        options: {
          indexAxis: 'y', // horizontal bars
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: '#fff',
              titleColor: '#e83e8c',
              bodyColor: '#222',
              borderColor: '#e83e8c',
              borderWidth: 1,
              callbacks: {
                label: function(context) {
                  const mood = moods[context.dataIndex];
                  return `Mood: ${mood}`;
                }
              }
            },
            title: {
              display: false
            }
          },
          scales: {
            x: {
              beginAtZero: true,
              max: 1,
              display: false,
              grid: { display: false }
            },
            y: {
              grid: { display: false },
              ticks: {
                color: '#6f42c1',
                font: { size: 16, weight: 'bold', family: 'Poppins, Arial' }
              }
            }
          },
          layout: {
            padding: 24
          },
          animation: {
            duration: 900,
            easing: 'easeOutQuart'
          }
        },
        plugins: [{
          id: 'barShadow',
          beforeDraw: chart => {
            const ctx = chart.ctx;
            ctx.save();
            chart.getDatasetMeta(0).data.forEach(bar => {
              ctx.shadowColor = '#e83e8c33';
              ctx.shadowBlur = 16;
              ctx.shadowOffsetY = 4;
              ctx.fillRect(bar.x, bar.y, bar.width, bar.height);
            });
            ctx.restore();
          }
        }]
      });
      renderMoodLegend();
    });
}
function renderMoodLegend() {
  let legend = document.getElementById('mood-legend');
  if (!legend) {
    legend = document.createElement('div');
    legend.id = 'mood-legend';
  legend.style.display = 'flex';
  legend.style.gap = '2.2rem';
  legend.style.margin = '1rem 0 1.5rem 0';
  legend.style.alignItems = 'center';
  legend.style.justifyContent = 'center';
  legend.style.fontSize = '1.15rem';
    moodChartCtx.canvas.parentNode.insertBefore(legend, moodChartCtx.canvas);
  }
  legend.innerHTML = Object.entries(moodColors).filter(([k])=>k!=='default').map(([mood, color]) =>
    `<span style="display:inline-flex;align-items:center;"><span style="display:inline-block;width:22px;height:22px;background:${color};border-radius:6px;margin-right:8px;box-shadow:0 2px 8px #e83e8c22;"></span>${mood}</span>`
  ).join(' ');
}
loadMoodChart();

moodForm.onsubmit = e => {
  e.preventDefault();
  fetch('../backend/mood.php?action=log', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      user_id: user.id,
      mood: moodSelect.value,
      mood_date: new Date().toISOString().slice(0,10)
    })
  }).then(res => res.json()).then(() => {
    loadMoodChart();
    Swal.fire('Mood logged!');
  });
};

// Report
const reportForm = document.getElementById('reportForm');
reportForm.onsubmit = e => {
  e.preventDefault();
  fetch('../backend/report.php?action=submit', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      user_id: user.id,
      type: document.getElementById('reportType').value,
      description: document.getElementById('reportDesc').value,
      location: document.getElementById('reportLocation').value
    })
  }).then(res => res.json()).then(data => {
    if (data.success) Swal.fire('Report submitted!');
    else Swal.fire('Error', 'Could not submit report', 'error');
  });
};

// Diary
const diaryForm = document.getElementById('diaryForm');
const diaryList = document.getElementById('diaryList');
function loadDiary() {
  fetch(`../backend/diary.php?action=list&user_id=${user.id}`)
    .then(res => res.json())
    .then(data => {
      diaryList.innerHTML = '';
      data.forEach(entry => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = entry.entry + ' (' + entry.created_at.slice(0,10) + ')';
        diaryList.appendChild(li);
      });
    });
}
loadDiary();
diaryForm.onsubmit = e => {
  e.preventDefault();
  fetch('../backend/diary.php?action=add', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      user_id: user.id,
      entry: document.getElementById('diaryEntry').value
    })
  }).then(res => res.json()).then(() => {
    loadDiary();
    Swal.fire('Entry saved!');
  });
};

// Stories
const storyForm = document.getElementById('storyForm');
const storyList = document.getElementById('storyList');
function loadStories() {
  fetch('../backend/stories.php?action=list')
    .then(res => res.json())
    .then(data => {
      storyList.innerHTML = '';
      data.forEach(story => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.innerHTML = `<b>${story.name}:</b> ${story.story}`;
        storyList.appendChild(li);
      });
    });
}
loadStories();
storyForm.onsubmit = e => {
  e.preventDefault();
  fetch('../backend/stories.php?action=submit', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      user_id: user.id,
      story: document.getElementById('storyEntry').value
    })
  }).then(res => res.json()).then(() => {
    Swal.fire('Story submitted! (Pending approval)');
  });
};

// SOS Button (WhatsApp)
document.getElementById('sosBtn').onclick = () => {
  if (!user.trusted_contact) {
    Swal.fire('No trusted contact set!');
    return;
  }
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      const lat = pos.coords.latitude;
      const lon = pos.coords.longitude;
      const msg = encodeURIComponent(`SOS! I need help. My location: https://maps.google.com/?q=${lat},${lon}`);
      window.open(`https://wa.me/${user.trusted_contact}?text=${msg}`);
    }, () => {
      Swal.fire('Could not get location!');
    });
  } else {
    Swal.fire('Geolocation not supported!');
  }
};

// Fake Call Button
document.getElementById('fakeCallBtn').onclick = () => {
  Swal.fire({
    title: 'Incoming Call',
    html: '<i class="fa fa-phone fa-3x text-success"></i><br><b>Mom</b> is calling...<br><small>00:00</small>',
    showConfirmButton: false,
    timer: 10000
  });
};
