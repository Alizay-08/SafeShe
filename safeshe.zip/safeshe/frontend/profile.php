<?php
session_start();
require_once __DIR__ . '/../config/db.php';

$avatarPath = 'assets/default-avatar.svg';
$userName = '';
if (!empty($_SESSION['user_id'])) {
  try {
    // try selecting avatar (newer schema)
    $stmt = $pdo->prepare('SELECT avatar, name FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
      if (!empty($user['avatar'])) {
        // user avatar stored like 'assets/uploads/avatars/filename'
        $avatarPath = '../' . ltrim($user['avatar'], '/');
      }
      $userName = $user['name'] ?? '';
    }
  } catch (PDOException $e) {
    // fallback: avatar column may not exist (older DB). Select name only.
    try {
      $stmt = $pdo->prepare('SELECT name FROM users WHERE id = ?');
      $stmt->execute([$_SESSION['user_id']]);
      $user = $stmt->fetch();
      if ($user) {
        $userName = $user['name'] ?? '';
      }
    } catch (PDOException $ex) {
      // give up silently; keep defaults
    }
  }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Profile - Safeshe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
      <div class="container">
        <a class="navbar-brand fw-bold text-danger" href="dashboard.php">Safeshe</a>
        <div class="ms-auto d-flex align-items-center">
          <a class="me-3" href="dashboard.php">Dashboard</a>
          <a href="profile.php" title="Your profile" class="me-2">
            <img 
              id="navAvatar" 
              src="<?php echo htmlspecialchars($avatarPath); ?>" 
              alt="Profile" 
              class="rounded-circle"
              style="width:34px;height:34px;object-fit:cover;border-radius:50%;border:1px solid rgba(0,0,0,0.1);display:block;"
            >
          </a>
        </div>
      </div>
    </nav>
    <div class="container mt-4">
      <div class="row">
        <div class="col-md-4">
          <div class="card">
            <div class="card-body text-center">
              <img id="avatarImg" src="../assets/default-avatar.svg" alt="Avatar" class="rounded-circle" width="140" height="140" aria-hidden="false">
              <h5 id="nameHeading" class="mt-2">Name</h5>
              <p id="emailText" class="text-muted">email@example.com</p>
            </div>
          </div>
        </div>
        <div class="col-md-8">
          <div class="card">
            <div class="card-body">
              <h5>Update Profile</h5>
              <form id="profileForm" enctype="multipart/form-data">
                <div class="mb-3">
                  <label class="form-label">Name</label>
                  <input name="name" id="name" class="form-control">
                </div>
                <div class="mb-3">
                  <label class="form-label">Trusted Contact</label>
                  <input name="trusted_contact" id="trusted_contact" class="form-control">
                </div>
                <div class="mb-3">
                  <label class="form-label">Bio</label>
                  <textarea name="bio" id="bio" class="form-control" rows="3"></textarea>
                </div>
                <div class="mb-3">
                  <label class="form-label">Avatar</label>
                  <input type="file" name="avatar" id="avatar" class="form-control">
                </div>
                <button class="btn btn-primary" type="submit">Save</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/profile.js"></script>
    <script src="../assets/navbar.js"></script>
  </body>
</html>
