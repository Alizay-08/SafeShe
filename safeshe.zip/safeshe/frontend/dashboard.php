<?php
session_start();
require_once __DIR__ . '/../config/db.php';

$avatarPath = 'assets/default-avatar.svg';
$userName = '';
if (!empty($_SESSION['user_id'])) {
  try {
    // try selecting avatar (newer schema)
    $stmt = $pdo->prepare('SELECT avatar, name FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
      if (!empty($user['avatar'])) {
        // user avatar stored like 'assets/uploads/avatars/filename'
        $avatarPath = '../' . ltrim($user['avatar'], '/');
      }
      $userName = $user['name'] ?? '';
    }
  } catch (PDOException $e) {
    // fallback: avatar column may not exist (older DB). Select name only.
    try {
      $stmt = $pdo->prepare('SELECT name FROM users WHERE id = ?');
      $stmt->execute([$_SESSION['user_id']]);
      $user = $stmt->fetch();
      if ($user) {
        $userName = $user['name'] ?? '';
      }
    } catch (PDOException $ex) {
      // give up silently; keep defaults
    }
  }
}
?>

</main>
<!-- Chatbot Widget -->
<div id="chatbot-widget" class="chatbot-widget">
  <div class="chatbot-header">
    <span><i class="fa-solid fa-robot"></i> Safeshe Chatbot</span>
    <button id="chatbot-close" aria-label="Close chat">&times;</button>
  </div>
  <div id="chatbot-messages" class="chatbot-messages">
    <div class="chatbot-msg chatbot-msg-bot">Hi! I am your Safeshe assistant. Ask me anything about the platform or safety tips.</div>
  </div>
  <form id="chatbot-form" autocomplete="off">
    <input type="text" id="chatbot-input" placeholder="Type your question..." required />
    <button type="submit"><i class="fa-solid fa-paper-plane"></i></button>
  </form>
</div>
<button id="chatbot-toggle" class="chatbot-toggle" aria-label="Open chat"><i class="fa-solid fa-robot"></i></button>

<style>
.chatbot-widget {
  position: fixed; bottom: 32px; right: 32px; width: 340px; max-width: 95vw;
  background: #fff; border-radius: 1.2rem; box-shadow: 0 8px 32px #e83e8c33;
  z-index: 9999; display: none; flex-direction: column; overflow: hidden;
  font-family: 'Poppins', Arial, sans-serif; animation: fadeInUp 0.6s;
}
.chatbot-header { background: linear-gradient(90deg,#e83e8c,#6f42c1); color: #fff; padding: 1rem; font-weight: 600; display: flex; justify-content: space-between; align-items: center; }
.chatbot-header button { background: none; border: none; color: #fff; font-size: 1.5rem; cursor: pointer; }
.chatbot-messages { padding: 1rem; height: 260px; overflow-y: auto; background: #f8f9fa; display: flex; flex-direction: column; gap: 0.5rem; }
.chatbot-msg { padding: 0.7rem 1rem; border-radius: 1rem; max-width: 80%; word-break: break-word; font-size: 1rem; }
.chatbot-msg-bot { background: #ffe6ea; color: #e83e8c; align-self: flex-start; box-shadow: 0 2px 8px #e83e8c11; }
.chatbot-msg-user { background: #6f42c1; color: #fff; align-self: flex-end; box-shadow: 0 2px 8px #6f42c122; }
#chatbot-form { display: flex; border-top: 1px solid #eee; }
#chatbot-input { flex: 1; border: none; padding: 0.8rem; font-size: 1rem; border-radius: 0 0 0 1.2rem; outline: none; }
#chatbot-form button { background: #e83e8c; border: none; color: #fff; padding: 0 1.2rem; border-radius: 0 0 1.2rem 0; font-size: 1.2rem; cursor: pointer; transition: background 0.2s; }
#chatbot-form button:hover { background: #6f42c1; }
.chatbot-toggle { position: fixed; bottom: 32px; right: 32px; z-index: 9998; background: linear-gradient(90deg,#e83e8c,#6f42c1); color: #fff; border: none; border-radius: 50%; width: 56px; height: 56px; font-size: 2rem; box-shadow: 0 4px 16px #e83e8c33; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.2s, transform 0.2s; }
.chatbot-toggle:hover { background: linear-gradient(90deg,#6f42c1,#e83e8c); transform: scale(1.08); }
@media (max-width: 600px) { .chatbot-widget { width: 98vw; right: 1vw; bottom: 1vw; } }
</style>
<script>
const chatbotWidget = document.getElementById('chatbot-widget');
const chatbotToggle = document.getElementById('chatbot-toggle');
const chatbotClose = document.getElementById('chatbot-close');
const chatbotForm = document.getElementById('chatbot-form');
const chatbotInput = document.getElementById('chatbot-input');
const chatbotMessages = document.getElementById('chatbot-messages');

chatbotToggle.onclick = () => { chatbotWidget.style.display = 'flex'; chatbotToggle.style.display = 'none'; chatbotInput.focus(); };
chatbotClose.onclick = () => { chatbotWidget.style.display = 'none'; chatbotToggle.style.display = 'flex'; };

chatbotForm.onsubmit = async (e) => {
  e.preventDefault();
  const msg = chatbotInput.value.trim();
  if (!msg) return;
  chatbotMessages.innerHTML += `<div class='chatbot-msg chatbot-msg-user'>${msg}</div>`;
  chatbotInput.value = '';
  chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
  // Send to backend
  try {
    const res = await fetch('../backend/chatbot.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'message=' + encodeURIComponent(msg)
    });
    const data = await res.json();
    chatbotMessages.innerHTML += `<div class='chatbot-msg chatbot-msg-bot'>${data.reply}</div>`;
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
  } catch {
    chatbotMessages.innerHTML += `<div class='chatbot-msg chatbot-msg-bot'>Sorry, there was a problem. Please try again.</div>`;
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
  }
};
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Safeshe – Dashboard</title>
    <meta name="description" content="Your Safeshe dashboard: access safety tools, helplines, mood tracker, diary, and more.">
    <meta name="keywords" content="dashboard, women safety, helplines, mood tracker, safeshe">
    <meta name="author" content="Safeshe Team">
    <link rel="icon" href="https://img.icons8.com/ios-filled/50/fa314a/woman-shield.png" type="image/png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm animate-fadein">
  <div class="container">
    <a class="navbar-brand fw-bold text-danger" href="index.html">
      <i class="fa-solid fa-shield-heart"></i> Safeshe
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto align-items-center">
        
        <!-- Profile avatar -->
        <li class="nav-item d-flex align-items-center me-2">
          <a class="nav-link p-0 d-flex align-items-center" href="profile.php" title="Your profile">
            <img 
              id="navAvatar" 
              src="<?php echo htmlspecialchars($avatarPath); ?>" 
              alt="Profile" 
              class="rounded-circle"
              style="width:34px;height:34px;object-fit:cover;border-radius:50%;border:1px solid rgba(0,0,0,0.1);display:block;"
            >
          </a>
        </li>

        <!-- Notification bell -->
        <li class="nav-item dropdown me-2">
          <a class="nav-link position-relative" href="#" id="notifBell" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fa-solid fa-bell fa-lg"></i>
            <span id="notifCount" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:0.65rem"></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notifBell" id="notifDropdown">
            <li><h6 class="dropdown-header">Notifications</h6></li>
            <li><div id="notifList" class="list-group list-group-flush"></div></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-center" href="#">View all</a></li>
          </ul>
        </li>

        <!-- Profile & Logout links -->
        <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
        <li class="nav-item"><a class="nav-link" href="#" id="logoutBtn">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4 animate-fadein">
  <!-- ...existing dashboard content can be placed here or included as needed... -->
  <h3>Welcome <?php echo htmlspecialchars($userName ?: 'User'); ?></h3>
</div>
<div class="container mt-4 animate-fadein">
  <div class="row g-3 flex-column-reverse flex-md-row">
    <div class="col-12 col-md-4">
      <div class="card text-center animate-slidein">
        <div class="card-body">
          <button class="btn btn-danger w-100 mb-2 hero-btn" id="sosBtn"><i class="fa fa-bell"></i> SOS</button>
          <button class="btn btn-secondary w-100 hero-btn" id="fakeCallBtn"><i class="fa fa-phone"></i> Fake Call</button>
        </div>
      </div>
      <div class="card mt-3 animate-slidein">
        <div class="card-body">
          <h5>Helplines</h5>
          <ul class="list-group" id="helplineList"></ul>
        </div>
      </div>
    </div>
  <div class="col-12 col-md-8">
      <div class="card mb-3 animate-slidein">
        <div class="card-body">
          <h5>Mood Tracker</h5>
          <canvas id="moodChart" height="100"></canvas>
          <form class="row g-2 mt-2" id="moodForm">
            <div class="col-auto">
              <select class="form-select" id="moodSelect">
                <option value="Happy">Happy</option>
                <option value="Sad">Sad</option>
                <option value="Angry">Angry</option>
                <option value="Anxious">Anxious</option>
                <option value="Confident">Confident</option>
              </select>
            </div>
            <div class="col-auto">
              <button type="submit" class="btn btn-danger hero-btn">Log Mood</button>
            </div>
          </form>
        </div>
      </div>
      <div class="card mb-3 animate-slidein">
        <div class="card-body">
          <h5>Report Harassment/Abuse</h5>
          <form id="reportForm">
            <div class="row g-2">
              <div class="col-md-4">
                <select class="form-select" id="reportType">
                  <option value="Harassment">Harassment</option>
                  <option value="Abuse">Abuse</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div class="col-md-5">
                <input type="text" class="form-control" id="reportLocation" placeholder="Location (optional)">
              </div>
              <div class="col-md-3">
                <button type="submit" class="btn btn-danger w-100 hero-btn">Report</button>
              </div>
            </div>
            <textarea class="form-control mt-2" id="reportDesc" rows="2" placeholder="Describe incident..."></textarea>
          </form>
        </div>
      </div>
      <div class="card mb-3 animate-slidein">
        <div class="card-body">
          <h5>Anonymous Diary</h5>
          <form id="diaryForm">
            <textarea class="form-control mb-2" id="diaryEntry" rows="2" placeholder="Write your thoughts..."></textarea>
            <button type="submit" class="btn btn-secondary hero-btn">Save Entry</button>
          </form>
          <ul class="list-group mt-2" id="diaryList"></ul>
        </div>
      </div>
      <div class="card mb-3">
        <div class="card-body">
          <h5>Success Stories</h5>
          <form id="storyForm">
            <textarea class="form-control mb-2" id="storyEntry" rows="2" placeholder="Share your story..."></textarea>
            <button type="submit" class="btn btn-success">Submit Story</button>
          </form>
          <ul class="list-group mt-2" id="storyList"></ul>
        </div>
      </div>
      <div class="card mb-3">
        <div class="card-body">
          <h5>Cyber Safety & Self-Defense Tips</h5>
          <ul>
            <li>Keep your social media private and secure.</li>
            <li>Never share passwords or OTPs.</li>
            <li>Learn basic self-defense moves.</li>
            <li>Block/report suspicious contacts online.</li>
            <li>Stay alert in public and trust your instincts.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../assets/dashboard.js"></script>
<script src="../assets/notifications.js"></script>
<script src="../assets/navbar.js"></script>
<script>
// Language toggle removed
  </script>
  <footer class="footer animate-fadein mt-5">
    <div class="container">
      <div class="footer-main">
        <div class="footer-col">
          <h6>About Safeshe</h6>
          <p>Safeshe is a digital safety platform empowering women with real-time support, privacy, and community. Your safety, our mission.</p>
        </div>
        <div class="footer-col">
          <h6>Quick Links</h6>
          <a href="index.html" class="footer-link">Home</a><br>
          <a href="register.html" class="footer-link">Register</a><br>
          <a href="login.html" class="footer-link">Login</a><br>
          <a href="dashboard.php" class="footer-link">Dashboard</a>
        </div>
        <div class="footer-col">
          <h6>Contact</h6>
          <div>Email: <a href="mailto:info@safeshe.com" class="footer-link">info@safeshe.com</a></div>
          <div>Helpline: <a href="tel:1122" class="footer-link">1122</a></div>
          <div class="footer-social mt-2">
            <a href="#" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
            <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
            <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
            <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        &copy; 2025 Safeshe. Empowering Women’s Safety. All rights reserved.
      </div>
    </div>
  </footer>
</body>
</html>
