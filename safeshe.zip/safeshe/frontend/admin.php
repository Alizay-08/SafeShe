<?php
session_start();
// simple admin page; assumes admin session exists
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Admin Panel - SafeShe</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Admin Panel</a>
  </div>
</nav>
<div class="container mt-4">
  <div class="row">
    <div class="col-md-3">
      <div class="list-group">
        <a href="#users" class="list-group-item list-group-item-action active">Users</a>
        <a href="#helplines" class="list-group-item list-group-item-action">Helplines</a>
        <a href="#stories" class="list-group-item list-group-item-action">Pending Stories</a>
        <a href="#profile" class="list-group-item list-group-item-action">My Profile</a>
      </div>
    </div>
    <div class="col-md-9">
      <div id="content">
          <div id="users" class="admin-section">
            <div class="d-flex justify-content-between align-items-center">
              <h4>Users</h4>
              <div>
                <button class="btn btn-sm btn-primary" id="createUserBtn">New User</button>
              </div>
            </div>
            <table class="table table-sm" id="usersTable"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Contact</th><th>Actions</th></tr></thead><tbody></tbody></table>
          </div>
          <div id="helplines" class="admin-section" style="display:none">
            <div class="d-flex justify-content-between align-items-center">
              <h4>Helplines</h4>
              <div>
                <button class="btn btn-sm btn-primary" id="createHelplineBtn">New Helpline</button>
              </div>
            </div>
            <table class="table table-sm" id="helplinesTable"><thead><tr><th>ID</th><th>Name</th><th>Number</th><th>Category</th><th>Actions</th></tr></thead><tbody></tbody></table>
          </div>
          <div id="stories" class="admin-section" style="display:none">
            <h4>Pending Stories</h4>
            <table class="table table-sm" id="storiesTable"><thead><tr><th>ID</th><th>User</th><th>Story</th><th>Actions</th></tr></thead><tbody></tbody></table>
          </div>
          <div id="profile" class="admin-section" style="display:none">
            <h4>My Profile</h4>
            <form id="adminProfileForm"><div class="mb-3"><label>Email</label><input class="form-control" name="email"></div><div class="mb-3"><label>Password</label><input class="form-control" name="password" type="password"></div><button class="btn btn-primary">Save</button></form>
          </div>
        </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Modals -->
<!-- User Modal -->
<div class="modal fade" id="userModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form id="userForm"><div class="modal-header"><h5 class="modal-title">User</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="id"><div class="mb-3"><label>Name</label><input class="form-control" name="name"></div><div class="mb-3"><label>Email</label><input class="form-control" name="email" type="email"></div><div class="mb-3"><label>Contact</label><input class="form-control" name="trusted_contact"></div><div class="mb-3"><label>Bio</label><textarea class="form-control" name="bio"></textarea></div></div><div class="modal-footer"><button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" type="submit">Save</button></div></form></div></div></div>

<!-- Helpline Modal -->
<div class="modal fade" id="helplineModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form id="helplineForm"><div class="modal-header"><h5 class="modal-title">Helpline</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="id"><div class="mb-3"><label>Name</label><input class="form-control" name="name"></div><div class="mb-3"><label>Number</label><input class="form-control" name="number"></div><div class="mb-3"><label>Category</label><input class="form-control" name="category"></div></div><div class="modal-footer"><button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" type="submit">Save</button></div></form></div></div></div>

<!-- Confirm Modal -->
<div class="modal fade" id="confirmModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="confirmBody"></div><div class="modal-footer"><button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Cancel</button><button class="btn btn-danger" id="confirmOk">Yes</button></div></div></div></div>

<script src="../assets/admin.js"></script>
</body>
</html>
